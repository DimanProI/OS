#include <stdio.h>
#include "fact.h"

int n = 10;

int main() {
  printf("Hello, World!\n");
  printf("fact of %i is %i\n", n, fact(n));
  return 0;
}
